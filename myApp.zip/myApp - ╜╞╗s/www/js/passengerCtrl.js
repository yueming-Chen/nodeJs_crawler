app.controller('passengerCtrl', function($scope) {
	console.log('success');
})